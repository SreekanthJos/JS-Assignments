import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountmaster',
  templateUrl: './accountmaster.component.html',
  styleUrls: ['./accountmaster.component.css']
})
export class AccountmasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
