import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmithistoryComponent } from './admithistory.component';

describe('AdmithistoryComponent', () => {
  let component: AdmithistoryComponent;
  let fixture: ComponentFixture<AdmithistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmithistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmithistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
