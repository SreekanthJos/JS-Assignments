import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admithistory',
  templateUrl: './admithistory.component.html',
  styleUrls: ['./admithistory.component.css']
})
export class AdmithistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
