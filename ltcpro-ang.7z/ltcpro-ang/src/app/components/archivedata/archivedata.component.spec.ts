import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchivedataComponent } from './archivedata.component';

describe('ArchivedataComponent', () => {
  let component: ArchivedataComponent;
  let fixture: ComponentFixture<ArchivedataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArchivedataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArchivedataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
