import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bankaccounts',
  templateUrl: './bankaccounts.component.html',
  styleUrls: ['./bankaccounts.component.css']
})
export class BankaccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
