import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exhibitedby',
  templateUrl: './exhibitedby.component.html',
  styleUrls: ['./exhibitedby.component.css']
})
export class ExhibitedbyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
