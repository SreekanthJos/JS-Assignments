import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facilitycontact',
  templateUrl: './facilitycontact.component.html',
  styleUrls: ['./facilitycontact.component.css']
})
export class FacilitycontactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
