import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facilityinformation',
  templateUrl: './facilityinformation.component.html',
  styleUrls: ['./facilityinformation.component.css']
})
export class FacilityinformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
