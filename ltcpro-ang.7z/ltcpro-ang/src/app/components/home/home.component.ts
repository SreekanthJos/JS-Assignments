import { Component, OnInit } from '@angular/core';
//import { DownloadService } from '../../services/download.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  // GetPdf()
  // {
  //   this.downloadService.downloadDoc().subscribe(result => {

  //     var url = window.URL.createObjectURL(result);
  //     window.open(url);
  //     console.log("download result ", result);
  // });
  // }

}
