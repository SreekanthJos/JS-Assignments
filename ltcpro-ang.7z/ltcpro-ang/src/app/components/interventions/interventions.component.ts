import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interventions',
  templateUrl: './interventions.component.html',
  styleUrls: ['./interventions.component.css']
})
export class InterventionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
