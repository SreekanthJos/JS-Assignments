import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-return',
  templateUrl: './leave-return.component.html',
  styleUrls: ['./leave-return.component.css']
})
export class LeaveReturnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
