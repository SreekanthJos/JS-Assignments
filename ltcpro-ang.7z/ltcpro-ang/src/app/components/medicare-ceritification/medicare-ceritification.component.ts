import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicare-ceritification',
  templateUrl: './medicare-ceritification.component.html',
  styleUrls: ['./medicare-ceritification.component.css']
})
export class MedicareCeritificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
