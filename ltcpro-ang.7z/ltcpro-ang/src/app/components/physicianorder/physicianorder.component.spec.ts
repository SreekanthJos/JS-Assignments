import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhysicianorderComponent } from './physicianorder.component';

describe('PhysicianorderComponent', () => {
  let component: PhysicianorderComponent;
  let fixture: ComponentFixture<PhysicianorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhysicianorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhysicianorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
