import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessionalvisitComponent } from './professionalvisit.component';

describe('ProfessionalvisitComponent', () => {
  let component: ProfessionalvisitComponent;
  let fixture: ComponentFixture<ProfessionalvisitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfessionalvisitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfessionalvisitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
