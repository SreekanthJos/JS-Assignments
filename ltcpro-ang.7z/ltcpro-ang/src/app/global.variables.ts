export const GlobalVariable = Object.freeze({
    LOAD_IMAGE: '../assets/images/loading.gif'
});