import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './components/header/header.component';
import { LoginComponent } from './components/login/login.component';
import { PersistanceService } from "./services/shared/persistance.service";

import { FooterComponent } from './components/footer/footer.component';
import { rootRoutes } from "./app.routing";
import { AuthgaurdService } from "./services/shared/authgaurd.service";
import { SidebarComponent } from './components/sidebar/sidebar.component';

import { RoominventoryComponent } from './components/roominventory/roominventory.component';
import { PhysicianorderComponent } from './components/physicianorder/physicianorder.component';
import { ProblemsComponent } from './components/problems/problems.component';
import { InterventionsComponent } from './components/interventions/interventions.component';
import { GoalsComponent } from './components/goals/goals.component';
import { RelatedtoComponent } from './components/relatedto/relatedto.component';
import { ExhibitedbyComponent } from './components/exhibitedby/exhibitedby.component';
import { AccountmasterComponent } from './components/accountmaster/accountmaster.component';
import { ArchivedataComponent } from './components/archivedata/archivedata.component';
import { BankaccountsComponent } from './components/bankaccounts/bankaccounts.component';
//import { FacilityinformationComponent } from './components/facilityinformation/facilityinformation.component';
import { UserComponent } from './components/user/user.component';
import { ResidentComponent } from './components/resident/resident.component';
import { DataService } from "./services/shared/dataservice.service";
import { InterceptorService } from "./services/shared/interceptor.service";
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'
import { FacilityModule } from "./facility/facility.module";
import { ResidentModule } from "./resident/resident.module";


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    
    FooterComponent,
    SidebarComponent, 
    
    //FacilityinfoComponent, BedtransferComponent,     FacilitycontactComponent, FacilityinformationComponent,
    
    RoominventoryComponent, PhysicianorderComponent, ProblemsComponent, InterventionsComponent, GoalsComponent, RelatedtoComponent,
    ExhibitedbyComponent, AccountmasterComponent, ArchivedataComponent, BankaccountsComponent,
    UserComponent, ResidentComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    RouterModule.forRoot(rootRoutes, { useHash: true }),
    HttpClientModule,
    FacilityModule,
ResidentModule

  ],
  providers: [PersistanceService, AuthgaurdService, DataService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true,
    },],
  bootstrap: [AppComponent]
})
export class AppModule { }
