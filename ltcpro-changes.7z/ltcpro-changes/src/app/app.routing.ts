import { Routes } from '@angular/router';
//import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';

import { AuthgaurdService } from './services/shared/authgaurd.service';

//import { FacilityinfoComponent } from './components/facilityinfo/facilityinfo.component';
//import { BedtransferComponent } from './components/bedtransfer/bedtransfer.component';
//import { FacilitycontactComponent } from './components/facilitycontact/facilitycontact.component';

import { RoominventoryComponent } from './components/roominventory/roominventory.component';
import { PhysicianorderComponent } from './components/physicianorder/physicianorder.component';
import { ProblemsComponent } from './components/problems/problems.component';
import { InterventionsComponent } from './components/interventions/interventions.component';
import { GoalsComponent } from './components/goals/goals.component';
import { RelatedtoComponent } from './components/relatedto/relatedto.component';
import { ExhibitedbyComponent } from './components/exhibitedby/exhibitedby.component';
import { AccountmasterComponent } from './components/accountmaster/accountmaster.component';
import { ArchivedataComponent } from './components/archivedata/archivedata.component';
import { BankaccountsComponent } from './components/bankaccounts/bankaccounts.component';
//import { FacilityinformationComponent } from './components/facilityinformation/facilityinformation.component';
import { UserComponent } from './components/user/user.component';
import { ResidentComponent } from './components/resident/resident.component';

export const rootRoutes: Routes = [
    { path: '', component: LoginComponent,pathMatch:'full'},
    { path: 'login', component: LoginComponent,pathMatch:'full'},
   
   {path:'roominventory',component:RoominventoryComponent,pathMatch: 'full'},
   {path:'phyorder',component:PhysicianorderComponent,pathMatch: 'full'},
   {path:'problem',component:ProblemsComponent,pathMatch: 'full'},
   {path:'intervention',component:InterventionsComponent,pathMatch: 'full'},
   {path:'goals',component:GoalsComponent,pathMatch: 'full'},
   {path:'relatedto',component:RelatedtoComponent,pathMatch: 'full'},
   {path:'exhibitedby',component:ExhibitedbyComponent,pathMatch: 'full'},
   {path:'accountmaster',component:AccountmasterComponent,pathMatch: 'full'},
   {path:'archivedata',component:ArchivedataComponent,pathMatch: 'full'},
   {path:'bankaccounts',component:BankaccountsComponent,pathMatch: 'full'},
  // {path:'facilityinformation',component:FacilityinformationComponent,pathMatch: 'full'},
   {path:'user',component:UserComponent,pathMatch: 'full'},
   {path:'resident',component:ResidentComponent,pathMatch: 'full'},
]

