import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-archivedata',
  templateUrl: './archivedata.component.html',
  styleUrls: ['./archivedata.component.css']
})
export class ArchivedataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
