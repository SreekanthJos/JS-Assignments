import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExhibitedbyComponent } from './exhibitedby.component';

describe('ExhibitedbyComponent', () => {
  let component: ExhibitedbyComponent;
  let fixture: ComponentFixture<ExhibitedbyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExhibitedbyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExhibitedbyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
