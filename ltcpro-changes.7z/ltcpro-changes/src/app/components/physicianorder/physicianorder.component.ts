import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-physicianorder',
  templateUrl: './physicianorder.component.html',
  styleUrls: ['./physicianorder.component.css']
})
export class PhysicianorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
