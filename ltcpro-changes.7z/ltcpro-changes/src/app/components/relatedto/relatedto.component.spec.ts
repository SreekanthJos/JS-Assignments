import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatedtoComponent } from './relatedto.component';

describe('RelatedtoComponent', () => {
  let component: RelatedtoComponent;
  let fixture: ComponentFixture<RelatedtoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelatedtoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelatedtoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
