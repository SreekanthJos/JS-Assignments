import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-relatedto',
  templateUrl: './relatedto.component.html',
  styleUrls: ['./relatedto.component.css']
})
export class RelatedtoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
