import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resident',
  templateUrl: './resident.component.html',
  styleUrls: ['./resident.component.css']
})
export class ResidentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
