import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoominventoryComponent } from './roominventory.component';

describe('RoominventoryComponent', () => {
  let component: RoominventoryComponent;
  let fixture: ComponentFixture<RoominventoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoominventoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoominventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
