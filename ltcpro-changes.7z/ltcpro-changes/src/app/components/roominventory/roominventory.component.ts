import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roominventory',
  templateUrl: './roominventory.component.html',
  styleUrls: ['./roominventory.component.css']
})
export class RoominventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
