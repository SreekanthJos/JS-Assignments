import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
public armenu:menu[]=[
  {name:"Facility Main",route:"facmain"},
{name:"Bed Transfer",route:"bedtransfer"},
{name:"Facility Contacts",route:"faccontact"},
{name:"Room Inventory",route:"/roominventory"},
{name:"Account Master",route:"/accountmaster"},
{name:"Archive Data",route:"/archivedata"},
{name:"Bank Accounts",route:"/bankaccounts"},
{name:"Facility Information",route:"/facilityinformation"},
{name:"User",route:"/user"},{name:"Resident",route:"/resident"}];
public facclick():void
{
  this.armenu=[];
  this.armenu.push({name:"Facility Main",route:"/facmain"});
  this.armenu.push({name:"Bed Transfer",route:"/bedtransfer"});
  this.armenu.push({name:"Facility Contacts",route:"/faccontact"});
  this.armenu.push({name:"Room Inventory",route:"/roominventory"});
  this.armenu.push({name:"Account Master",route:"/accountmaster"});
  this.armenu.push({name:"Archive Data",route:"/archivedata"});
  this.armenu.push({name:"Bank Accounts",route:"/bankaccounts"});
  this.armenu.push({name:"Facility Information",route:"/facilityinformation"});
  this.armenu.push({name:"User",route:"/user"});
  this.armenu.push({name:"Resident",route:"/resident"});
  this.router.navigate(['/facmain']);
}
public resclick():void
{
  this.armenu=[];
  this.armenu.push({name:"Demographic",route:"/home"});
  this.armenu.push({name:"Admit History",route:"/admithistory"});
  this.armenu.push({name:"Aims Assessment",route:"/aimsassessment"});
  this.armenu.push({name:"Barden Assessment",route:"/bardenassessment"});
  this.armenu.push({name:"Diagnosis",route:"/diagnosis"});
  this.armenu.push({name:"Payor Information",route:"//payorinfo"});
  this.armenu.push({name:"Professional Contact",route:"profcont"});
  this.armenu.push({name:"immunization",route:"immunization"});
  this.armenu.push({name:"Alerts",route:"alerts"});
  this.armenu.push({name:"Leave",route:"leave"});
  this.armenu.push({name:"Events",route:"events"});
  this.armenu.push({name:"Professional Visit",route:"profvisit"});  
  this.armenu.push({name:"Allergies",route:"allergies"});
  this.armenu.push({name:"Audits",route:"audits"});
  this.armenu.push({name:"Personal Contacts",route:"personal-contacts"});
  this.armenu.push({name:"Leave / Return",route:"leave-return"});
  this.armenu.push({name:"medicare ceritification",route:"medicare-ceritification"});
  this.armenu.push({name:"Progress Notes",route:"progress-notes"});
  this.armenu.push({name:"Room history",route:"room-history"});
  this.armenu.push({name:"Therapy",route:"therapy"});
  this.armenu.push({name:"Weight / Vitals",route:"weight/vitals"});
  this.armenu.push({name:"Care Plan",route:"care-plan"});
  this.router.navigate(['/home']);
}
public phyclick():void
{
  this.armenu=[];
  this.armenu.push({name:"Physician Orders",route:"/phyorder"});
  this.armenu.push({name:"Problems",route:"/problem"});
  this.armenu.push({name:"Interventions",route:"/intervention"});
  this.armenu.push({name:"Goals",route:"/goals"});
  this.armenu.push({name:"Related To's",route:"/relatedto"});
  this.armenu.push({name:"Exhibited By's",route:"/exhibitedby"});
  this.router.navigate(['/phyorder']);
}
}
export class menu
{
public name:string="";
public route:string="";
}