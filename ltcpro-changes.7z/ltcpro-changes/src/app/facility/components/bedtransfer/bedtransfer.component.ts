import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bedtransfer',
  templateUrl: './bedtransfer.component.html',
  styleUrls: ['./bedtransfer.component.css']
})
export class BedtransferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
