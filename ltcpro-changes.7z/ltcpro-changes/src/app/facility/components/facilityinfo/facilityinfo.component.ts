import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facilityinfo',
  templateUrl: './facilityinfo.component.html',
  styleUrls: ['./facilityinfo.component.css']
})
export class FacilityinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
