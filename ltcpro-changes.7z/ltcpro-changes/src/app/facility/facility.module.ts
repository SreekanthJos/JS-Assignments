import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";

import { CommonModule } from '@angular/common';
import { FacilityinfoComponent } from './components/facilityinfo/facilityinfo.component';
import { BedtransferComponent } from './components/bedtransfer/bedtransfer.component';
import { FacilitycontactComponent } from './components/facilitycontact/facilitycontact.component';
import { facilityRoutes } from "./facility.routing";
import { AuthgaurdService } from "../services/shared/authgaurd.service";
import { FacilityinformationComponent } from "./components/facilityinformation/facilityinformation.component";
import { PersistanceService } from "../services/shared/persistance.service";
import { DataService } from "../services/shared/dataservice.service";
import { InterceptorService } from "../services/shared/interceptor.service";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
@NgModule({
  imports: [
    CommonModule,
    
    RouterModule.forRoot(facilityRoutes,{useHash:true})
  
  ],
  declarations: [FacilityinfoComponent,BedtransferComponent,FacilitycontactComponent,FacilityinformationComponent],
  providers: [PersistanceService, AuthgaurdService, DataService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true,
    },],
  exports:[RouterModule]
})
export class FacilityModule { }
