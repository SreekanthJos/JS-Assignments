import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FacilityinfoComponent } from './components/facilityinfo/facilityinfo.component';
import { BedtransferComponent } from './components/bedtransfer/bedtransfer.component';
import { FacilitycontactComponent } from './components/facilitycontact/facilitycontact.component';
import { Routes } from '@angular/router';
import { AuthgaurdService } from '../services/shared/authgaurd.service';
import { FacilityinformationComponent } from './components/facilityinformation/facilityinformation.component';
export const facilityRoutes: Routes = [
     {path:'facmain',component:FacilityinfoComponent,pathMatch: 'full',canActivate:[AuthgaurdService]},
   {path:'bedtransfer',component:BedtransferComponent,pathMatch: 'full',canActivate:[AuthgaurdService]},
   {path:'faccontact',component:FacilitycontactComponent,pathMatch: 'full',canActivate:[AuthgaurdService]},
   {path:'facilityinformation',component:FacilityinformationComponent,pathMatch: 'full',canActivate:[AuthgaurdService]},
];

