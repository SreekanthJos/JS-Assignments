import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BardenassessmentComponent } from './bardenassessment.component';

describe('BardenassessmentComponent', () => {
  let component: BardenassessmentComponent;
  let fixture: ComponentFixture<BardenassessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BardenassessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BardenassessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
