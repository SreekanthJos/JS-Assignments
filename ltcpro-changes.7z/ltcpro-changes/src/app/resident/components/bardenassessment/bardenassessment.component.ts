import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bardenassessment',
  templateUrl: './bardenassessment.component.html',
  styleUrls: ['./bardenassessment.component.css']
})
export class BardenassessmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
