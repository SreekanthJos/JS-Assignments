import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-care-plan',
  templateUrl: './care-plan.component.html',
  styleUrls: ['./care-plan.component.css']
})
export class CarePlanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
