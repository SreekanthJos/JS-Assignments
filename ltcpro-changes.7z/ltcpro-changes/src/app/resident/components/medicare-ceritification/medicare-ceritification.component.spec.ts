import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicareCeritificationComponent } from './medicare-ceritification.component';

describe('MedicareCeritificationComponent', () => {
  let component: MedicareCeritificationComponent;
  let fixture: ComponentFixture<MedicareCeritificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicareCeritificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicareCeritificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
