import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payorinfo',
  templateUrl: './payorinfo.component.html',
  styleUrls: ['./payorinfo.component.css']
})
export class PayorinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
