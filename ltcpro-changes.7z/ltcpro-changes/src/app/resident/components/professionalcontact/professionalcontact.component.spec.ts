import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessionalcontactComponent } from './professionalcontact.component';

describe('ProfessionalcontactComponent', () => {
  let component: ProfessionalcontactComponent;
  let fixture: ComponentFixture<ProfessionalcontactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfessionalcontactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfessionalcontactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
