import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-professionalcontact',
  templateUrl: './professionalcontact.component.html',
  styleUrls: ['./professionalcontact.component.css']
})
export class ProfessionalcontactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
