import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-professionalvisit',
  templateUrl: './professionalvisit.component.html',
  styleUrls: ['./professionalvisit.component.css']
})
export class ProfessionalvisitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
