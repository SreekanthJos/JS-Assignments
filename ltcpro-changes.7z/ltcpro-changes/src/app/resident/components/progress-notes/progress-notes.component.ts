import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progress-notes',
  templateUrl: './progress-notes.component.html',
  styleUrls: ['./progress-notes.component.css']
})
export class ProgressNotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
