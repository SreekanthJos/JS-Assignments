import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-room-history',
  templateUrl: './room-history.component.html',
  styleUrls: ['./room-history.component.css']
})
export class RoomHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
