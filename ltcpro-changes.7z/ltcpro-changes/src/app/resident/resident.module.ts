import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { residentRoutes } from './resident.routing';
import { HomeComponent } from './components/home/home.component';
import { AdmithistoryComponent } from './components/admithistory/admithistory.component';
import { AimsassessmentComponent } from './components/aimsassessment/aimsassessment.component';
import { BardenassessmentComponent } from './components/bardenassessment/bardenassessment.component';
import { DiagnosisComponent } from './components/diagnosis/diagnosis.component';
import { PayorinfoComponent } from './components/payorinfo/payorinfo.component';
import { ProfessionalcontactComponent } from './components/professionalcontact/professionalcontact.component';
import { ImmunizationComponent } from './components/immunization/immunization.component';
import { AlertsComponent } from './components/alerts/alerts.component';
import { LeaveComponent } from './components/leave/leave.component';
import { EventsComponent } from './components/events/events.component';
import { ProfessionalvisitComponent } from './components/professionalvisit/professionalvisit.component';
import { AllergiesComponent } from './components/allergies/allergies.component';
import { AuditsComponent } from './components/audits/audits.component';
import { PersonalContactsComponent } from './components/personal-contacts/personal-contacts.component';
import { MedicareCeritificationComponent } from './components/medicare-ceritification/medicare-ceritification.component';
import { ProgressNotesComponent } from './components/progress-notes/progress-notes.component';
import { RoomHistoryComponent } from './components/room-history/room-history.component';
import { RouterModule } from '@angular/router';
import { LeaveReturnComponent } from './components/leave-return/leave-return.component';
import { CarePlanComponent } from './components/care-plan/care-plan.component';
import { VitalsComponent } from './components/weight/vitals/vitals.component';
import { TherapyComponent } from './components/therapy/therapy.component';
import { PersistanceService } from '../services/shared/persistance.service';
import { AuthgaurdService } from '../services/shared/authgaurd.service';
import { DataService } from '../services/shared/dataservice.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { InterceptorService } from '../services/shared/interceptor.service';

@NgModule({
  declarations: [
    HomeComponent,
     AdmithistoryComponent, AimsassessmentComponent, BardenassessmentComponent,
    DiagnosisComponent, PayorinfoComponent, ProfessionalcontactComponent, ImmunizationComponent, AlertsComponent,
    LeaveComponent, EventsComponent, ProfessionalvisitComponent,
    //FacilityinfoComponent, BedtransferComponent,     FacilitycontactComponent, FacilityinformationComponent,
    AllergiesComponent, AuditsComponent, PersonalContactsComponent, MedicareCeritificationComponent,
    ProgressNotesComponent, RoomHistoryComponent, TherapyComponent, VitalsComponent, CarePlanComponent, LeaveReturnComponent,
      
       
    ],
  imports: [
    CommonModule,
    
    RouterModule.forRoot(residentRoutes,{useHash:true})


  ],
  providers: [PersistanceService, AuthgaurdService, DataService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true,
    },],
    exports:[RouterModule]
})
export class ResidentModule { }
