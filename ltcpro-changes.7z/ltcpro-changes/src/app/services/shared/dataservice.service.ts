import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { APIConfiguration } from '../../models/app.constants';
@Injectable()
export class DataService {

  constructor(private http: HttpClient, private config: APIConfiguration) {

  }

  get<T>(url: string): Observable<T> {
    url = this.config.serverWithApiUrl + url;
    return this.http.get<T>(url);
  }
  post<T>(url: string, body: string): Observable<T> {
    url = this.config.serverWithApiUrl + url;
    return this.http.post<T>(url, body);
  }

  put<T>(url: string, body: string): Observable<T> {
    url = this.config.serverWithApiUrl + url;
    return this.http.put<T>(url, body);
  }

  delete<T>(url: string): Observable<T> {
    url = this.config.serverWithApiUrl + url;
    return this.http.delete<T>(url);
  }

}
