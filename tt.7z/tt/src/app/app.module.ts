import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './components/header/header.component';
import { LoginComponent } from './components/login/login.component';
import { PersistanceService } from "./shared/persistance.service";
import { HomeComponent } from './components/home/home.component';
import { FooterComponent } from './components/footer/footer.component';
import { rootRoutes } from "./app.routing";
import { AuthgaurdService } from "./shared/authgaurd.service";
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { AdmithistoryComponent } from './components/admithistory/admithistory.component';
import { AimsassessmentComponent } from './components/aimsassessment/aimsassessment.component';
import { BardenassessmentComponent } from './components/bardenassessment/bardenassessment.component';
import { DiagnosisComponent } from './components/diagnosis/diagnosis.component';
import { PayorinfoComponent } from './components/payorinfo/payorinfo.component';
import { ProfessionalcontactComponent } from './components/professionalcontact/professionalcontact.component';
import { ImmunizationComponent } from './components/immunization/immunization.component';
import { AlertsComponent } from './components/alerts/alerts.component';
import { LeaveComponent } from './components/leave/leave.component';
import { EventsComponent } from './components/events/events.component';
import { ProfessionalvisitComponent } from './components/professionalvisit/professionalvisit.component';
import { FacilityinfoComponent } from './components/facilityinfo/facilityinfo.component';
import { BedtransferComponent } from './components/bedtransfer/bedtransfer.component';
import { FacilitycontactComponent } from './components/facilitycontact/facilitycontact.component';
import { AllergiesComponent } from './components/allergies/allergies.component';
import { AuditsComponent } from './components/audits/audits.component';
import { PersonalContactsComponent } from './components/personal-contacts/personal-contacts.component';

import { MedicareCeritificationComponent } from './components/medicare-ceritification/medicare-ceritification.component';
import { ProgressNotesComponent } from './components/progress-notes/progress-notes.component';
import { RoomHistoryComponent } from './components/room-history/room-history.component';
import { TherapyComponent } from './components/therapy/therapy.component';
import { VitalsComponent } from './components/weight/vitals/vitals.component';
import { CarePlanComponent } from './components/care-plan/care-plan.component';
import { LeaveReturnComponent } from './components/leave-return/leave-return.component';



@NgModule({
  declarations: [AppComponent, HeaderComponent, LoginComponent, HomeComponent, FooterComponent, SidebarComponent, AdmithistoryComponent, AimsassessmentComponent, BardenassessmentComponent, DiagnosisComponent, PayorinfoComponent, ProfessionalcontactComponent, ImmunizationComponent, AlertsComponent, LeaveComponent, EventsComponent, ProfessionalvisitComponent, FacilityinfoComponent, BedtransferComponent, FacilitycontactComponent, AllergiesComponent, AuditsComponent, PersonalContactsComponent, MedicareCeritificationComponent, ProgressNotesComponent, RoomHistoryComponent, TherapyComponent, VitalsComponent, CarePlanComponent, LeaveReturnComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    RouterModule.forRoot(rootRoutes,{useHash:true})
  
  ],
  providers: [PersistanceService,AuthgaurdService],
  bootstrap: [AppComponent]
})
export class AppModule {}
