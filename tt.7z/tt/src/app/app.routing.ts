import { Routes } from '@angular/router';
//import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { AuthgaurdService } from './shared/authgaurd.service';
import { AdmithistoryComponent } from './components/admithistory/admithistory.component';
import { AimsassessmentComponent } from './components/aimsassessment/aimsassessment.component';
import { BardenassessmentComponent } from './components/bardenassessment/bardenassessment.component';
import { DiagnosisComponent } from './components/diagnosis/diagnosis.component';
import { PayorinfoComponent } from './components/payorinfo/payorinfo.component';
import { ProfessionalcontactComponent } from './components/professionalcontact/professionalcontact.component';
import { ImmunizationComponent } from './components/immunization/immunization.component';
import { AlertsComponent } from './components/alerts/alerts.component';
import { LeaveComponent } from './components/leave/leave.component';
import { EventsComponent } from './components/events/events.component';
import { ProfessionalvisitComponent } from './components/professionalvisit/professionalvisit.component';
import { FacilityinfoComponent } from './components/facilityinfo/facilityinfo.component';
import { BedtransferComponent } from './components/bedtransfer/bedtransfer.component';
import { FacilitycontactComponent } from './components/facilitycontact/facilitycontact.component';
import { AllergiesComponent } from './components/allergies/allergies.component';
import { AuditsComponent } from './components/audits/audits.component';
import { PersonalContactsComponent } from './components/personal-contacts/personal-contacts.component';
import { LeaveReturnComponent } from './components/leave-return/leave-return.component';
import { MedicareCeritificationComponent } from './components/medicare-ceritification/medicare-ceritification.component';
import { ProgressNotesComponent } from './components/progress-notes/progress-notes.component';
import { RoomHistoryComponent } from './components/room-history/room-history.component';
import { TherapyComponent } from './components/therapy/therapy.component';
import { VitalsComponent } from './components/weight/vitals/vitals.component';
import { CarePlanComponent } from './components/care-plan/care-plan.component';

export const rootRoutes: Routes = [
    { path: '', component: LoginComponent,pathMatch:'full'},
    { path: 'login', component: LoginComponent,pathMatch:'full'},
   {path:'home',component:HomeComponent,pathMatch: 'full',canActivate:[AuthgaurdService]},
   {path:'admithistory',component:AdmithistoryComponent,pathMatch: 'full'},
   {path:'aimsassessment',component:AimsassessmentComponent,pathMatch: 'full'},
   {path:'bardenassessment',component:BardenassessmentComponent,pathMatch: 'full'},
   {path:'diagnosis',component:DiagnosisComponent,pathMatch: 'full'},
   {path:'payorinfo',component:PayorinfoComponent,pathMatch: 'full'},
   {path:'profcont',component:ProfessionalcontactComponent,pathMatch: 'full'},
   {path:'immunization',component:ImmunizationComponent,pathMatch: 'full'},
   {path:'alerts',component:AlertsComponent,pathMatch: 'full'},
   {path:'leave',component:LeaveComponent,pathMatch: 'full'},
   {path:'events',component:EventsComponent,pathMatch: 'full'},
   {path:'profvisit',component:ProfessionalvisitComponent,pathMatch: 'full'},
   {path:'facmain',component:FacilityinfoComponent,pathMatch: 'full'},
   {path:'bedtransfer',component:BedtransferComponent,pathMatch: 'full'},
   {path:'faccontact',component:FacilitycontactComponent,pathMatch: 'full'},
   {path:'allergies',component:AllergiesComponent,pathMatch: 'full'},
   {path:'audits',component:AuditsComponent,pathMatch: 'full'},
   {path:'personal-contacts',component:PersonalContactsComponent,pathMatch: 'full'},
   {path:'medicare-ceritification',component:MedicareCeritificationComponent,pathMatch: 'full'},
   {path:'progress-notes',component:ProgressNotesComponent,pathMatch: 'full'},
   {path:'room-history',component:RoomHistoryComponent,pathMatch: 'full'},
   {path:'therapy',component:TherapyComponent,pathMatch: 'full'},
   {path:'weight/vitals',component:VitalsComponent,pathMatch: 'full'},
   {path:'care-plan',component:CarePlanComponent,pathMatch: 'full'},
   {path:'leave-return',component:LeaveReturnComponent,pathMatch: 'full'},
]

