import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AimsassessmentComponent } from './aimsassessment.component';

describe('AimsassessmentComponent', () => {
  let component: AimsassessmentComponent;
  let fixture: ComponentFixture<AimsassessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AimsassessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AimsassessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
