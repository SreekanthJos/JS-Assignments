import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aimsassessment',
  templateUrl: './aimsassessment.component.html',
  styleUrls: ['./aimsassessment.component.css']
})
export class AimsassessmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
