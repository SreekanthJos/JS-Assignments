import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilitycontactComponent } from './facilitycontact.component';

describe('FacilitycontactComponent', () => {
  let component: FacilitycontactComponent;
  let fixture: ComponentFixture<FacilitycontactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacilitycontactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilitycontactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
