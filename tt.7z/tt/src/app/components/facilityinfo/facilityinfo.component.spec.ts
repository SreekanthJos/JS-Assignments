import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilityinfoComponent } from './facilityinfo.component';

describe('FacilityinfoComponent', () => {
  let component: FacilityinfoComponent;
  let fixture: ComponentFixture<FacilityinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacilityinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilityinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
