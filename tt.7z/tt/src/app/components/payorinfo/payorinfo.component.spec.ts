import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayorinfoComponent } from './payorinfo.component';

describe('PayorinfoComponent', () => {
  let component: PayorinfoComponent;
  let fixture: ComponentFixture<PayorinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayorinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayorinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
