import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-contacts',
  templateUrl: './personal-contacts.component.html',
  styleUrls: ['./personal-contacts.component.css']
})
export class PersonalContactsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
