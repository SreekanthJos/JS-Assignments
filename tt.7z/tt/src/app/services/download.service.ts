import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class DownloadService {
  apiUrl="http://localhost:52992/";
  constructor(private http:HttpClient) { }
  downloadDoc(): Observable<any> {
    let url = this.apiUrl + "api/pdf";
    return this.http.get(url,{responseType:"blob"});
}
}
